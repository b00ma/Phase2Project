import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payinitiated',
  templateUrl: './payinitiated.component.html',
  styleUrls: ['./payinitiated.component.css']
})
export class PayinitiatedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
