import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminpage',
  templateUrl: './adminpage.component.html',
  styleUrls: ['./adminpage.component.css']
})
export class AdminpageComponent implements OnInit {
  uname:any;
  msg1:string='';

  item?:any[];
  z:any={};
  msg?:string;
  constructor(){

    this.uname=localStorage.getItem("uname");
    this.msg1=`Hello ${this.uname}, Welcome to Admin Page...`;

    this.item=[
      {"id":1001,"iname":"Idly","price":20},
      {"id":1002,"iname":"Dosa","price":40},
      {"id":1003,"iname":"Poori","price":30},
      {"id":1004,"iname":"Roti","price":25},
      {"id":1005,"iname":"Parotha","price":25},
      {"id":1006,"iname":"Veg Biryani","price":60},
      {"id":1007,"iname":"Fried Rice","price":65},
      {"id":1008,"iname":"Noodles","price":50},
      {"id":1009,"iname":"Momos","price":40},
      {"id":1010,"iname":"Curd Rice","price":25}
    ];
    this.msg=`Count of Food Items: ${this.item?.length}`;
  }

  getitembyID(id:number){
    this.z=JSON.parse(JSON.stringify(this.item?.find(z=>z.id==id)));
  }

  additem(){
    this.item?.push(this.z);
    this.msg=`Count of Food Items: ${this.item?.length}`;
  }

  deleteitembyID(ID:number){
    var i=Number(this.item?.findIndex(z=>z.id==ID));
    this.item?.splice(i,1);
    this.msg=`Count of Food Items: ${this.item?.length}`;
  }

  edititembyID(ID:number){
    var i=Number(this.item?.findIndex(z=>z.id==ID));
    this.item?.splice(i,1,this.z);
  }
 ngOnInit(): void {
  }
}
