import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'app-ulogin',
  templateUrl: './ulogin.component.html',
  styleUrls: ['./ulogin.component.css']
})
export class UloginComponent implements OnInit {

  uname:string='';
  pwd:string='';
  users=[
    {"uname":"A Soppia","pwd":"soppia"},
    {"uname":"Aishwarya","pwd":"kamakodi"},
    {"uname":"Abhilash","pwd":"reddy"},
    {"uname":"Adarsh","pwd":"kumar"},
    {"uname":"Jagannath","pwd":"jagan"}
  ];
  validateUser(){
    if(this.users.find(x=>x.uname==this.uname && x.pwd==this.pwd)){
      localStorage.setItem("uname",this.uname);
      this._router.navigate(['./userpage']);
    }
    else this.msg='Invalid Credentials!';
  }
  msg:string='';
  constructor(private _router:Router) { }

  ngOnInit(): void {
  }

}
